package wohnung;

public class Programmclass {

	public static void main(String[] args) {
		System.out.printf("%n%n---------------------- Test Haus ---------------------------%n%n");
		Haus h1 = new Haus(10);
		h1.print();

	}

}
